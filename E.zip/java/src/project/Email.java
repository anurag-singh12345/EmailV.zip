import java.util.regex.*;    
import java.util.*;    
public class EmailValidation{  
    public static void main(String args[]){  
        ArrayList<String> emails = new ArrayList<String>();  
        emails.add("java@domain.co.in");  
        emails.add("java@domain.com");  
        emails.add("java.name@domain.com");  
        emails.add("java#@domain.co.in");  
        emails.add("java@domain.com");  
        emails.add("java@domaincom");  
      
        emails.add("@yahoo.com");  
        emails.add("java#domain.com");  
         
        String regex = "^(.+)@(.+)$";  
        
        Pattern pattern = Pattern.compile(regex);  
         
        for(String email : emails){  
               
            Matcher matcher = pattern.matcher(email);  
            System.out.println(email +" : "+ matcher.matches()+"\n");  
        }  
    }  
}  